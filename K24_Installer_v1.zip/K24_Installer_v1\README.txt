﻿K24 INSTALLER

1. Run INSTALL_K24.bat
2. Follow instructions.
